importScripts("page-actions.js", "permission-logic.js");

const BROKER_URL = "ws://127.0.0.1:47821/ext";
const LOAD_TIMEOUT_MS = 10000;
const tabsByName = new Map();
let socket = null;
const permissionQueue = [];
const promptingGrants = new Set();

function connect() {
  if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) return;
  socket = new WebSocket(BROKER_URL);
  socket.onmessage = (event) => {
    let message;
    try {
      message = JSON.parse(event.data);
    } catch {
      return;
    }
    if (message && message.type === "command") void handle(message);
    else if (message && message.type === "grant-approved") void queueGrantPermission(message.grant);
    else if (message && message.type === "notice" && message.presence) {
      const tabId = tabsByName.get(message.tab);
      if (tabId !== undefined) announce(tabId, message.presence, message.presence.target && message.presence.target.selector);
    }
  };
  socket.onclose = () => {
    socket = null;
    setTimeout(connect, 2000);
  };
  socket.onerror = () => socket && socket.close();
}

function originOf(url) {
  try {
    const parsed = new URL(url);
    return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.origin : null;
  } catch {
    return null;
  }
}

async function originNow(tabId) {
  try {
    return originOf((await chrome.tabs.get(tabId)).url);
  } catch {
    return null;
  }
}

async function urlNow(tabId) {
  try {
    const url = (await chrome.tabs.get(tabId)).url;
    return typeof url === "string" ? url : null;
  } catch {
    return null;
  }
}

function pathWithinGrant(url, prefix) {
  return M9RPermissionLogic.pathWithinGrant(url, prefix);
}

async function hasHostPermission(url, expectedOrigin, pathPrefix) {
  const origin = M9RPermissionLogic.normalizeOrigin(url);
  const pattern = origin && M9RPermissionLogic.permissionPattern(origin);
  if (!pattern || (expectedOrigin && origin !== expectedOrigin)) return false;
  try {
    const granted = await chrome.permissions.contains({ origins: [pattern] });
    return granted && M9RPermissionLogic.mayActOnUrl(url, expectedOrigin || null, [pattern], pathPrefix);
  } catch {
    return false;
  }
}

function queueGrantPermission(value) {
  const grant = M9RPermissionLogic.normalizeApprovedGrant(value);
  if (!grant || promptingGrants.has(grant.grantId) || permissionQueue.some((item) => item.grantId === grant.grantId)) return;
  promptingGrants.add(grant.grantId);
  permissionQueue.push(grant);
  void showNextPermissionPrompt();
}

async function showNextPermissionPrompt() {
  const grant = permissionQueue[0];
  if (!grant) return;
  const pattern = M9RPermissionLogic.permissionPattern(grant.origin);
  try {
    if (pattern && await chrome.permissions.contains({ origins: [pattern] })) {
      await reportPermissionResult(grant, true);
      return;
    }
    const query = new URLSearchParams({ grantId: grant.grantId, origin: grant.origin, pathPrefix: grant.pathPrefix, actions: grant.actions.join(",") });
    await chrome.tabs.create({ url: chrome.runtime.getURL(`permission.html?${query.toString()}`), active: true });
  } catch {
    // Leave the grant unusable; every action re-checks the browser permission below.
  }
}

async function reportPermissionResult(grant, granted) {
  if (socket && socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify({ type: "permission-result", grantId: grant.grantId, origin: grant.origin, granted }));
  const index = permissionQueue.findIndex((item) => item.grantId === grant.grantId);
  if (index >= 0) permissionQueue.splice(index, 1);
  promptingGrants.delete(grant.grantId);
  await showNextPermissionPrompt();
}

chrome.runtime.onMessage.addListener((message) => {
  if (!message || message.type !== "m9r-permission-result") return;
  const grant = permissionQueue.find((item) => item.grantId === message.grantId && item.origin === message.origin);
  if (grant && typeof message.granted === "boolean") void reportPermissionResult(grant, message.granted);
});

async function ensurePresenceOverlay(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["src/presence-logic.js", "src/presence-overlay.js", "src/content.js"] });
  } catch {
    // The page may have navigated or the user may have revoked its host access.
  }
}

function reply(id, result, origin, url) {
  if (!socket || socket.readyState !== WebSocket.OPEN) return;
  socket.send(JSON.stringify({ type: "result", id, ok: result.ok, data: result.data, error: result.error, origin: origin || undefined, url: url || undefined }));
}

function announce(tabId, presence, selector) {
  void ensurePresenceOverlay(tabId).then(() => {
  chrome.tabs
    .sendMessage(tabId, { type: "presence", ...presence, target: selector ? { selector } : presence.target || null })
    .catch(() => {});
  });
}

function waitForLoad(tabId) {
  return new Promise((resolve) => {
    const timer = setTimeout(done, LOAD_TIMEOUT_MS);
    function done() {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }
    function listener(id, info) {
      if (id === tabId && info.status === "complete") done();
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function existingTab(name) {
  const id = tabsByName.get(name);
  if (id === undefined) return null;
  try {
    return await chrome.tabs.get(id);
  } catch {
    tabsByName.delete(name);
    return null;
  }
}

async function run(tabId, func, args) {
  try {
    const [injection] = await chrome.scripting.executeScript({ target: { tabId }, func, args });
    return injection.result || { ok: false, error: "the page returned nothing" };
  } catch (error) {
    return { ok: false, error: "this extension can only act on localhost pages right now (" + (error && error.message ? error.message : error) + ")" };
  }
}

async function handle(command) {
  try {
    if (command.action === "open") {
      if (!await hasHostPermission(command.url, command.expectOrigin || null, command.expectPathPrefix)) return reply(command.id, { ok: false, error: "M9R has no Chrome permission for this site; approve access from the M9R site-consent screen first" });
      const tab = await existingTab(command.tab);
      const opened = tab ? await chrome.tabs.update(tab.id, { url: command.url }) : await chrome.tabs.create({ url: command.url, active: false });
      tabsByName.set(command.tab, opened.id);
      await waitForLoad(opened.id);
      const actualUrl = await urlNow(opened.id);
      const landed = originOf(actualUrl);
      if (command.expectOrigin && landed !== command.expectOrigin) {
        await chrome.tabs.update(opened.id, { url: "about:blank" });
        return reply(command.id, { ok: false, error: "the page ended up outside the granted site" }, null);
      }
      if (command.expectPathPrefix && !pathWithinGrant(actualUrl, command.expectPathPrefix)) {
        await chrome.tabs.update(opened.id, { url: "about:blank" });
        return reply(command.id, { ok: false, error: "the page ended up outside the granted path" }, landed, actualUrl);
      }
      announce(opened.id, command.presence, null);
      return reply(command.id, { ok: true, data: { tab: command.tab, url: command.url } }, landed, actualUrl);
    }

    const tab = await existingTab(command.tab);
    if (!tab) return reply(command.id, { ok: false, error: 'tab "' + command.tab + '" is not open; call m9r_web_open first' });
    const current = originOf(tab.url);
    if (!await hasHostPermission(tab.url, command.expectOrigin || null, command.expectPathPrefix)) return reply(command.id, { ok: false, error: "M9R has no Chrome permission for this site or granted path" }, current, tab.url);
    if (command.expectOrigin && current !== command.expectOrigin) {
      return reply(command.id, { ok: false, error: "the tab is no longer on the granted site" }, current);
    }
    if (command.expectPathPrefix && !pathWithinGrant(tab.url, command.expectPathPrefix)) {
      return reply(command.id, { ok: false, error: "the tab is no longer within the granted path" }, current, tab.url);
    }
    announce(tab.id, command.presence, command.selector);

    let result;
    if (command.action === "read") result = await run(tab.id, m9rPageRead, [command.selector || null, command.expectOrigin || null, command.expectPathPrefix || null]);
    else if (command.action === "click") result = await run(tab.id, m9rPageClick, [command.selector, command.expectOrigin || null, command.expectPathPrefix || null]);
    else if (command.action === "type") result = await run(tab.id, m9rPageType, [command.selector, command.text, command.expectOrigin || null, command.expectPathPrefix || null]);
    else result = { ok: false, error: "unknown action " + command.action };
    return reply(command.id, result, await originNow(tab.id), await urlNow(tab.id));
  } catch (error) {
    return reply(command.id, { ok: false, error: String(error && error.message ? error.message : error) });
  }
}

chrome.alarms.create("m9r-keepalive", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(() => {
  connect();
  if (socket && socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify({ type: "ping" }));
});

connect();
