(function () {
  "use strict";
  if (window.top !== window) return;
  if (document.getElementById(window.M9RPresence.ROOT_ID)) return;

  const overlay = window.M9RPresence.createPresenceOverlay(document);

  if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === "presence") overlay.update(msg);
    });
  }

  document.addEventListener("m9r:presence", (event) => {
    let msg = event.detail;
    if (typeof msg === "string") {
      try {
        msg = JSON.parse(msg);
      } catch {
        return;
      }
    }
    if (!msg || typeof msg !== "object") return;
    if (msg.type === "leave") overlay.remove(String(msg.agent || ""));
    else overlay.update(msg);
  });
})();
